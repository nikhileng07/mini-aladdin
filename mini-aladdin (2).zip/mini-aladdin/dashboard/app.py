"""
app.py — Premium Mini-Aladdin Dashboard
Each portfolio has different stocks and weights.
"""

import numpy as np
import pandas as pd
from scipy import stats
import plotly.graph_objects as go
import plotly.express as px
import dash
from dash import dcc, html, Input, Output, dash_table
import dash_bootstrap_components as dbc
import yfinance as yf
import os
import warnings
warnings.filterwarnings("ignore")

os.makedirs("/app/assets", exist_ok=True)
with open("/app/assets/style.css", "w") as f:
    f.write("""
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600&family=Share+Tech+Mono&display=swap');
* { box-sizing: border-box; }
body { background: #030712 !important; background-image: radial-gradient(ellipse at 20% 50%, rgba(0,255,136,0.03) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(0,255,255,0.03) 0%, transparent 50%), radial-gradient(ellipse at 50% 80%, rgba(191,95,255,0.03) 0%, transparent 50%); font-family: 'Rajdhani', sans-serif !important; min-height: 100vh; }
.main-title { font-family: 'Orbitron', monospace !important; font-size: 2.2rem !important; font-weight: 900 !important; background: linear-gradient(135deg, #FFD700 0%, #00FFFF 50%, #00FF88 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; letter-spacing: 4px; text-transform: uppercase; filter: drop-shadow(0 0 20px rgba(255,215,0,0.4)); margin: 0 !important; }
.sub-title { font-family: 'Share Tech Mono', monospace !important; color: rgba(0,255,255,0.45) !important; font-size: 0.7rem !important; letter-spacing: 6px !important; text-transform: uppercase !important; margin-top: 6px !important; }
.header-bar { border-bottom: 1px solid rgba(0,255,255,0.1); padding: 20px 0 16px 0; margin-bottom: 24px; position: relative; }
.header-bar::after { content: ''; position: absolute; bottom: -1px; left: 0; width: 220px; height: 1px; background: linear-gradient(90deg, #00FFFF, transparent); box-shadow: 0 0 10px #00FFFF; }
.port-badge { display: inline-block; font-family: 'Share Tech Mono', monospace; font-size: 0.65rem; letter-spacing: 2px; padding: 4px 10px; border-radius: 4px; margin-top: 8px; }
.port-badge-aggressive { background: rgba(255,68,102,0.15); border: 1px solid rgba(255,68,102,0.4); color: #FF4466; }
.port-badge-balanced   { background: rgba(255,215,0,0.1);  border: 1px solid rgba(255,215,0,0.4);  color: #FFD700; }
.port-badge-conservative { background: rgba(0,255,136,0.1); border: 1px solid rgba(0,255,136,0.4); color: #00FF88; }
.kpi-card { background: linear-gradient(135deg, #0d1117 0%, #0a0f1a 100%) !important; border: 1px solid rgba(0,255,255,0.15) !important; border-radius: 12px !important; padding: 18px 16px !important; position: relative; overflow: hidden; transition: all 0.3s ease; height: 100%; }
.kpi-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px; background: linear-gradient(90deg, transparent, rgba(0,255,255,0.5), transparent); }
.kpi-card:hover { border-color: rgba(0,255,255,0.45) !important; box-shadow: 0 0 25px rgba(0,255,255,0.08) !important; transform: translateY(-3px); }
.kpi-label { font-family: 'Share Tech Mono', monospace !important; font-size: 0.6rem !important; letter-spacing: 3px !important; color: rgba(255,255,255,0.3) !important; text-transform: uppercase !important; margin-bottom: 10px !important; }
.kpi-value-green  { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#00FF88!important; text-shadow:0 0 20px rgba(0,255,136,0.7)!important; }
.kpi-value-red    { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#FF4466!important; text-shadow:0 0 20px rgba(255,68,102,0.7)!important; }
.kpi-value-gold   { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#FFD700!important; text-shadow:0 0 20px rgba(255,215,0,0.7)!important; }
.kpi-value-cyan   { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#00FFFF!important; text-shadow:0 0 20px rgba(0,255,255,0.7)!important; }
.kpi-value-orange { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#FF8C00!important; text-shadow:0 0 20px rgba(255,140,0,0.7)!important; }
.kpi-value-purple { font-family:'Orbitron',monospace!important; font-size:1.5rem!important; font-weight:700!important; color:#BF5FFF!important; text-shadow:0 0 20px rgba(191,95,255,0.7)!important; }
.chart-panel { background: linear-gradient(135deg, #0d1117 0%, #0a0f1a 100%) !important; border: 1px solid rgba(0,255,255,0.08) !important; border-radius: 16px !important; padding: 4px !important; margin-bottom: 20px !important; position: relative; overflow: hidden; }
.chart-panel::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(255,215,0,0.3), rgba(0,255,255,0.3), transparent); }
.section-title { font-family: 'Orbitron', monospace !important; font-size: 0.62rem !important; letter-spacing: 4px !important; color: rgba(255,215,0,0.6) !important; text-transform: uppercase !important; padding: 14px 18px 0 !important; margin: 0 !important; }
.risk-table-wrap { background: linear-gradient(135deg, #0d1117 0%, #0a0f1a 100%); border: 1px solid rgba(0,255,255,0.08); border-radius: 16px; padding: 24px; margin-top: 8px; margin-bottom: 32px; position: relative; overflow: hidden; }
.risk-table-wrap::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(255,215,0,0.4), transparent); }
.risk-table-title { font-family: 'Orbitron', monospace !important; font-size: 0.7rem !important; letter-spacing: 4px !important; color: #FFD700 !important; text-transform: uppercase !important; margin-bottom: 18px !important; text-shadow: 0 0 10px rgba(255,215,0,0.4); }
select { background: #0d1117 !important; border: 1px solid rgba(0,255,255,0.2) !important; color: #00FFFF !important; font-family: 'Share Tech Mono', monospace !important; border-radius: 8px !important; padding: 8px 12px !important; font-size: 0.8rem !important; letter-spacing: 1px !important; outline: none !important; width: 100% !important; margin-bottom: 8px !important; cursor: pointer !important; transition: border-color 0.2s, box-shadow 0.2s !important; }
select:hover { border-color: rgba(0,255,255,0.5) !important; box-shadow: 0 0 12px rgba(0,255,255,0.1) !important; }
select option { background: #0d1117 !important; color: #00FFFF !important; }
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: #0d1117; }
::-webkit-scrollbar-thumb { background: rgba(0,255,255,0.25); border-radius: 2px; }
.scan-line { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,255,0.004) 2px, rgba(0,255,255,0.004) 4px); pointer-events: none; z-index: 9999; }
""")

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.DARKLY], title="Mini-Aladdin", suppress_callback_exceptions=True)

BENCHMARK    = "SPY"
TRADING_DAYS = 252
RF_DAILY     = (1.05) ** (1 / 252) - 1
NEON_GOLD    = "#FFD700"
NEON_CYAN    = "#00FFFF"
NEON_GREEN   = "#00FF88"
NEON_RED     = "#FF4466"
NEON_PURPLE  = "#BF5FFF"
NEON_ORANGE  = "#FF8C00"
NEON_COLORS  = ["#00FFFF","#FFD700","#00FF88","#BF5FFF","#FF8C00","#FF6B9D","#4ECDC4","#FF4466"]

# ── Each portfolio is genuinely different ─────────────────────────────────────
PORTFOLIOS = {
    "PORT-001": {
        "label":       "PORT-001 — AGGRESSIVE GROWTH",
        "description": "AGGRESSIVE — HIGH RISK / HIGH REWARD",
        "badge":       "aggressive",
        "color":       NEON_RED,
        "weights": {
            "TSLA":  0.30,
            "AAPL":  0.25,
            "GOOGL": 0.20,
            "AMZN":  0.15,
            "MSFT":  0.10,
        }
    },
    "PORT-002": {
        "label":       "PORT-002 — BALANCED",
        "description": "BALANCED — MODERATE RISK / STEADY RETURNS",
        "badge":       "balanced",
        "color":       NEON_GOLD,
        "weights": {
            "AAPL":  0.20,
            "MSFT":  0.20,
            "JPM":   0.20,
            "GOOGL": 0.20,
            "GS":    0.10,
            "BAC":   0.10,
        }
    },
    "PORT-003": {
        "label":       "PORT-003 — CONSERVATIVE",
        "description": "CONSERVATIVE — LOW RISK / STABLE INCOME",
        "badge":       "conservative",
        "color":       NEON_GREEN,
        "weights": {
            "JPM":  0.30,
            "BAC":  0.25,
            "GS":   0.25,
            "MSFT": 0.10,
            "AAPL": 0.10,
        }
    },
}

ALL_SYMBOLS = list(set(s for p in PORTFOLIOS.values() for s in p["weights"]))

def sharpe(r):
    return float(((r-RF_DAILY).mean()/r.std())*np.sqrt(TRADING_DAYS)) if r.std()>0 else 0.0
def sortino(r):
    d=r[r<RF_DAILY]; return float(((r-RF_DAILY).mean()*TRADING_DAYS)/(d.std()*np.sqrt(TRADING_DAYS))) if len(d)>0 and d.std()>0 else 0.0
def max_dd(r):
    c=(1+r).cumprod(); return float(((c-c.cummax())/c.cummax()).min())
def dd_series(r):
    c=(1+r).cumprod(); return (c-c.cummax())/c.cummax()
def var_h(r,c=0.95): return float(np.percentile(r,(1-c)*100))
def cvar(r,c=0.95):
    v=var_h(r,c); t=r[r<=v]; return float(t.mean()) if len(t)>0 else v
def beta_alpha(p,b):
    a=pd.concat([p,b],axis=1).dropna()
    if len(a)<10: return 0.0,0.0
    sl,ic,_,_,_=stats.linregress(a.iloc[:,1],a.iloc[:,0]); return float(sl),float(ic*TRADING_DAYS)
def ann_ret(r): return float((1+r).prod()**(TRADING_DAYS/len(r))-1)
def ann_vol(r): return float(r.std()*np.sqrt(TRADING_DAYS))
def calmar(r):
    md=abs(max_dd(r)); return float(ann_ret(r)/md) if md>0 else 0.0
def get_port_ret(returns, weights_dict):
    symbols = [s for s in weights_dict if s in returns.columns]
    w = np.array([weights_dict[s] for s in symbols])
    w = w / w.sum()
    return (returns[symbols] * w).sum(axis=1)

PLOTLY_LAYOUT = dict(
    template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Rajdhani, sans-serif", color="rgba(255,255,255,0.65)"),
    margin=dict(l=40,r=20,t=30,b=40), hovermode="x unified",
    hoverlabel=dict(bgcolor="#0d1117", bordercolor="rgba(0,255,255,0.3)", font=dict(family="Share Tech Mono", color="#00FFFF", size=11)),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(0,255,255,0.1)", borderwidth=1),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.06)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.06)"),
)

app.layout = html.Div([
    html.Div(className="scan-line"),
    dbc.Container([
        html.Div([
            dbc.Row([
                dbc.Col([
                    html.H1("MINI-ALADDIN", className="main-title"),
                    html.P("PORTFOLIO RISK & ANALYTICS PLATFORM", className="sub-title"),
                    html.Div(id="port-badge"),
                ], width=7),
                dbc.Col([
                    dbc.Select(id="portfolio-select",
                        options=[{"label": v["label"], "value": k} for k,v in PORTFOLIOS.items()],
                        value="PORT-001", className="mb-2"),
                    dbc.Select(id="period-select", options=[
                        {"label": "01M — 1 MONTH",  "value": "1mo"},
                        {"label": "06M — 6 MONTHS", "value": "6mo"},
                        {"label": "01Y — 1 YEAR",   "value": "1y"},
                        {"label": "02Y — 2 YEARS",  "value": "2y"},
                    ], value="1y"),
                ], width=5, className="d-flex flex-column justify-content-center"),
            ], className="align-items-center"),
        ], className="header-bar"),

        dbc.Row(id="kpi-cards", className="mb-4 g-3"),

        dbc.Row([
            dbc.Col([html.Div([html.P("CUMULATIVE RETURNS VS BENCHMARK", className="section-title"), dcc.Graph(id="cum-ret", config={"displayModeBar":False})], className="chart-panel")], width=8),
            dbc.Col([html.Div([html.P("PORTFOLIO WEIGHTS", className="section-title"), dcc.Graph(id="weights", config={"displayModeBar":False})], className="chart-panel")], width=4),
        ], className="mb-1"),

        dbc.Row([
            dbc.Col([html.Div([html.P("DRAWDOWN ANALYSIS", className="section-title"), dcc.Graph(id="drawdown", config={"displayModeBar":False})], className="chart-panel")], width=6),
            dbc.Col([html.Div([html.P("RETURN DISTRIBUTION & VAR", className="section-title"), dcc.Graph(id="var-chart", config={"displayModeBar":False})], className="chart-panel")], width=6),
        ], className="mb-1"),

        dbc.Row([
            dbc.Col([html.Div([html.P("ASSET CORRELATION MATRIX", className="section-title"), dcc.Graph(id="corr-matrix", config={"displayModeBar":False})], className="chart-panel")], width=6),
            dbc.Col([html.Div([html.P("ROLLING 63-DAY SHARPE RATIO", className="section-title"), dcc.Graph(id="roll-sharpe", config={"displayModeBar":False})], className="chart-panel")], width=6),
        ], className="mb-1"),

        html.Div([
            html.P("FULL RISK REPORT", className="risk-table-title"),
            html.Div(id="risk-table"),
        ], className="risk-table-wrap"),

    ], fluid=True),
])

@app.callback(
    Output("port-badge",  "children"),
    Output("kpi-cards",   "children"),
    Output("cum-ret",     "figure"),
    Output("weights",     "figure"),
    Output("drawdown",    "figure"),
    Output("var-chart",   "figure"),
    Output("corr-matrix", "figure"),
    Output("roll-sharpe", "figure"),
    Output("risk-table",  "children"),
    Input("portfolio-select", "value"),
    Input("period-select",    "value"),
)
def update(portfolio_id, period):
    config      = PORTFOLIOS[portfolio_id]
    weights_dict= config["weights"]
    port_color  = config["color"]
    symbols     = list(weights_dict.keys())

    prices    = yf.download(symbols + [BENCHMARK], period=period, progress=False)["Close"].dropna()
    returns   = prices.pct_change().dropna()
    bench_ret = returns[BENCHMARK]
    pr        = get_port_ret(returns, weights_dict)

    b,a=beta_alpha(pr,bench_ret); sh=sharpe(pr); so=sortino(pr)
    md=max_dd(pr); v95=var_h(pr); v99=var_h(pr,0.99); cv=cvar(pr)
    ar=ann_ret(pr); av=ann_vol(pr); tr=float((1+pr).prod()-1); cal=calmar(pr)

    # Badge
    badge = html.Span(config["description"], className=f"port-badge port-badge-{config['badge']}")

    # KPI Cards
    kpi_data=[
        ("TOTAL RETURN", f"{tr:+.1%}", "green" if tr>0 else "red"),
        ("SHARPE RATIO",  f"{sh:.2f}", "gold"  if sh>1 else "orange"),
        ("MAX DRAWDOWN",  f"{md:.1%}", "red"),
        ("VAR 95%",      f"{v95:.2%}", "orange"),
        ("ANN. VOL",      f"{av:.1%}", "cyan"),
        ("BETA",          f"{b:.2f}",  "purple"),
    ]
    cards=[dbc.Col(html.Div([html.P(l,className="kpi-label"),html.Div(v,className=f"kpi-value-{c}")],className="kpi-card"),width=2) for l,v,c in kpi_data]

    # Cumulative Returns
    cum_p=(1+pr).cumprod()-1; cum_b=(1+bench_ret).cumprod()-1
    fig_r=go.Figure([
        go.Scatter(x=cum_p.index, y=cum_p.values, name=portfolio_id, line=dict(color=port_color,width=2.5), fill="tozeroy", fillcolor=f"rgba{tuple(list(int(port_color.lstrip('#')[i:i+2],16) for i in (0,2,4))+[0.05])}"),
        go.Scatter(x=cum_b.index, y=cum_b.values, name="S&P 500",   line=dict(color="rgba(255,255,255,0.2)",width=1.5,dash="dot")),
    ])
    fig_r.update_layout(**PLOTLY_LAYOUT, yaxis_tickformat=".0%")

    # Weights donut — only this portfolio's stocks
    w_labels = list(weights_dict.keys())
    w_values = list(weights_dict.values())
    fig_w=go.Figure(go.Pie(labels=w_labels, values=w_values, hole=0.55,
        marker=dict(colors=NEON_COLORS[:len(w_labels)], line=dict(color="#030712",width=3)),
        textfont=dict(family="Rajdhani",size=12)))
    fig_w.update_layout(**PLOTLY_LAYOUT, annotations=[dict(text="WEIGHTS",x=0.5,y=0.5,font=dict(family="Orbitron",size=9,color=NEON_CYAN),showarrow=False)])

    # Drawdown
    dd=dd_series(pr)
    fig_dd=go.Figure(go.Scatter(x=dd.index,y=dd.values,fill="tozeroy",fillcolor="rgba(255,68,102,0.12)",line=dict(color=NEON_RED,width=1.5)))
    fig_dd.update_layout(**PLOTLY_LAYOUT,yaxis_tickformat=".0%")

    # VaR
    fig_v=go.Figure([go.Histogram(x=pr,nbinsx=60,marker_color=NEON_CYAN,opacity=0.45)])
    fig_v.add_vline(x=v95,line_color=NEON_ORANGE,line_dash="dash",line_width=2,annotation=dict(text=f"VaR 95%  {v95:.2%}",font=dict(color=NEON_ORANGE,family="Share Tech Mono",size=10)))
    fig_v.add_vline(x=cv, line_color=NEON_RED,   line_dash="dash",line_width=2,annotation=dict(text=f"CVaR  {cv:.2%}",font=dict(color=NEON_RED,family="Share Tech Mono",size=10),y=0.7))
    fig_v.update_layout(**PLOTLY_LAYOUT)

    # Correlation — only this portfolio's stocks
    corr=returns[symbols].corr()
    fig_c=go.Figure(go.Heatmap(z=corr.values,x=corr.columns,y=corr.index,colorscale=[[0,"#FF4466"],[0.5,"#0d1117"],[1,"#00FFFF"]],zmid=0,zmin=-1,zmax=1,text=corr.round(2).values,texttemplate="%{text}",textfont=dict(family="Share Tech Mono",size=10)))
    fig_c.update_layout(**PLOTLY_LAYOUT)

    # Rolling Sharpe
    rs=pr.rolling(63).apply(lambda x:(x.mean()-RF_DAILY)/x.std()*np.sqrt(TRADING_DAYS) if x.std()>0 else 0,raw=True)
    fig_rs=go.Figure([go.Scatter(x=rs.index,y=rs.values,line=dict(color=NEON_PURPLE,width=2),fill="tozeroy",fillcolor="rgba(191,95,255,0.05)")])
    fig_rs.add_hline(y=1.0,line_dash="dash",line_color=NEON_GREEN,line_width=1,annotation=dict(text="GOOD ▶ 1.0",font=dict(color=NEON_GREEN,family="Share Tech Mono",size=9)))
    fig_rs.add_hline(y=0.0,line_dash="dot", line_color="rgba(255,255,255,0.08)",line_width=1)
    fig_rs.update_layout(**PLOTLY_LAYOUT)

    # Risk Table
    metrics=[
        ("Annualized Return",    f"{ar:.2%}"),("Annualized Volatility",f"{av:.2%}"),
        ("Sharpe Ratio",         f"{sh:.2f}"),("Sortino Ratio",        f"{so:.2f}"),
        ("Calmar Ratio",         f"{cal:.2f}"),("Max Drawdown",         f"{md:.2%}"),
        ("VaR 95% (Historical)", f"{v95:.2%}"),("VaR 99% (Historical)", f"{v99:.2%}"),
        ("CVaR 95%",             f"{cv:.2%}"), ("Beta vs S&P 500",      f"{b:.2f}"),
        ("Alpha (Annualized)",   f"{a:.2%}"),
    ]
    table=dash_table.DataTable(
        data=[{"METRIC":m,"VALUE":v} for m,v in metrics],
        columns=[{"name":"METRIC","id":"METRIC"},{"name":"VALUE","id":"VALUE"}],
        style_table={"background":"transparent","border":"none"},
        style_header={"backgroundColor":"rgba(0,255,255,0.05)","color":"rgba(0,255,255,0.55)","fontFamily":"Orbitron, monospace","fontSize":"0.58rem","letterSpacing":"3px","border":"none","borderBottom":"1px solid rgba(0,255,255,0.12)","padding":"12px 16px"},
        style_data={"backgroundColor":"transparent","color":"rgba(255,255,255,0.75)","fontFamily":"Rajdhani, sans-serif","fontSize":"1rem","border":"none","borderBottom":"1px solid rgba(255,255,255,0.04)"},
        style_cell={"textAlign":"left","padding":"10px 16px"},
        style_data_conditional=[
            {"if":{"column_id":"VALUE"},"fontFamily":"Share Tech Mono, monospace","fontSize":"0.88rem","color":NEON_GOLD,"textAlign":"right"},
            {"if":{"row_index":"odd"},"backgroundColor":"rgba(0,255,255,0.015)"},
        ],
    )
    return badge, cards, fig_r, fig_w, fig_dd, fig_v, fig_c, fig_rs, table

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8050, debug=False)