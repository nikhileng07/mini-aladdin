"""
settings.py
-----------
Centralized config using pydantic-settings.
All values can be overridden via environment variables or .env file.
"""

from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):

    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = Field(default="localhost:29092", env="KAFKA_BOOTSTRAP_SERVERS")

    # Spark
    SPARK_MASTER_URL: str = Field(default="spark://localhost:7077", env="SPARK_MASTER_URL")

    # MinIO / S3
    MINIO_ENDPOINT: str = Field(default="http://localhost:9000", env="MLFLOW_S3_ENDPOINT_URL")
    MINIO_ACCESS_KEY: str = Field(default="minioadmin", env="AWS_ACCESS_KEY_ID")
    MINIO_SECRET_KEY: str = Field(default="minioadmin", env="AWS_SECRET_ACCESS_KEY")
    MINIO_BUCKET: str = Field(default="mini-aladdin", env="MINIO_BUCKET")

    # Database
    POSTGRES_DSN: str = Field(
        default="postgresql+psycopg2://airflow:airflow@localhost:5432/airflow",
        env="AIRFLOW__DATABASE__SQL_ALCHEMY_CONN"
    )
    DUCKDB_PATH: str = Field(default="data/processed/mini_aladdin.duckdb", env="DUCKDB_PATH")

    # App
    ENV: str = Field(default="development", env="ENV")
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


settings = Settings()