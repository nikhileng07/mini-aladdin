"""
daily_risk_dag.py
-----------------
Airflow DAG for Mini-Aladdin daily risk pipeline.
No external provider dependencies — pure PythonOperators only.
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule
import json
import sys
sys.path.insert(0, "/opt/airflow")

DEFAULT_ARGS = {
    "owner": "mini-aladdin",
    "depends_on_past": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "execution_timeout": timedelta(hours=2),
}

SYMBOLS    = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "JPM", "GS", "BAC"]
PORTFOLIOS = ["PORT-001", "PORT-002", "PORT-003"]
BENCHMARK  = "SPY"


def check_market_open(**context):
    from datetime import date
    today = date.today()
    if today.weekday() >= 5:  # Saturday=5, Sunday=6
        return "skip_pipeline"
    return "ingest_market_data"


def ingest_market_data(**context):
    import yfinance as yf
    import pandas as pd
    import os
    from datetime import date

    os.makedirs("data/raw", exist_ok=True)
    execution_date = context["ds"]

    prices = yf.download(
        SYMBOLS + [BENCHMARK],
        period="5d",
        progress=False
    )["Close"]

    prices = prices.dropna()
    output_path = f"data/raw/prices_{execution_date}.csv"
    prices.to_csv(output_path)

    print(f"Ingested {len(prices)} rows for {len(prices.columns)} symbols")
    print(f"Saved to {output_path}")

    context["ti"].xcom_push(key="price_path", value=output_path)
    context["ti"].xcom_push(key="row_count",  value=len(prices))


def validate_data(**context):
    import pandas as pd

    price_path = context["ti"].xcom_pull(key="price_path", task_ids="ingest_market_data")
    df = pd.read_csv(price_path, index_col=0)

    checks = {
        "row_count":    len(df),
        "col_count":    len(df.columns),
        "null_count":   int(df.isnull().sum().sum()),
        "zero_prices":  int((df == 0).sum().sum()),
    }

    print(f"Data quality checks: {checks}")

    if checks["null_count"] > len(df) * 0.1:
        raise ValueError(f"Too many nulls: {checks['null_count']}")
    if checks["row_count"] < 1:
        raise ValueError("No data ingested")

    context["ti"].xcom_push(key="dq_checks", value=checks)


def compute_risk_metrics(**context):
    import pandas as pd
    import numpy as np
    from scipy import stats
    from datetime import date
    import os
    import json

    os.makedirs("data/processed/analytics", exist_ok=True)

    price_path = context["ti"].xcom_pull(key="price_path", task_ids="ingest_market_data")
    execution_date = context["ds"]

    # Load prices
    try:
        prices = pd.read_csv(price_path, index_col=0, parse_dates=True)
    except Exception:
        import yfinance as yf
        prices = yf.download(SYMBOLS + [BENCHMARK], period="2y", progress=False)["Close"].dropna()

    # Get 2y data for proper metrics
    import yfinance as yf
    prices = yf.download(SYMBOLS + [BENCHMARK], period="2y", progress=False)["Close"].dropna()
    returns = prices.pct_change().dropna()

    TRADING_DAYS = 252
    RF_DAILY = (1.05) ** (1 / 252) - 1

    reports = {}
    for portfolio_id in PORTFOLIOS:
        n = len(SYMBOLS)
        w = np.array([1/n] * n)
        cols = [s for s in SYMBOLS if s in returns.columns]
        port_ret  = (returns[cols] * w[:len(cols)]).sum(axis=1)
        bench_ret = returns[BENCHMARK]

        # Core metrics
        total_ret = float((1 + port_ret).prod() - 1)
        ann_ret   = float((1 + port_ret).prod() ** (TRADING_DAYS / len(port_ret)) - 1)
        ann_vol   = float(port_ret.std() * np.sqrt(TRADING_DAYS))
        sharpe    = float(((port_ret - RF_DAILY).mean() / port_ret.std()) * np.sqrt(TRADING_DAYS)) if port_ret.std() > 0 else 0
        cum       = (1 + port_ret).cumprod()
        max_dd    = float(((cum - cum.cummax()) / cum.cummax()).min())
        var_95    = float(np.percentile(port_ret, 5))

        # Beta
        aligned = pd.concat([port_ret, bench_ret], axis=1).dropna()
        beta, _, _, _, _ = stats.linregress(aligned.iloc[:, 1], aligned.iloc[:, 0])

        reports[portfolio_id] = {
            "portfolio_id":         portfolio_id,
            "as_of_date":           execution_date,
            "total_return":         round(total_ret, 4),
            "annualized_return":    round(ann_ret, 4),
            "annualized_volatility":round(ann_vol, 4),
            "sharpe_ratio":         round(sharpe, 4),
            "max_drawdown":         round(max_dd, 4),
            "var_95":               round(var_95, 4),
            "beta":                 round(float(beta), 4),
        }

    # Save reports
    report_path = f"data/processed/analytics/risk_report_{execution_date}.json"
    with open(report_path, "w") as f:
        json.dump(reports, f, indent=2)

    print("\n" + "="*60)
    print(f"RISK REPORT — {execution_date}")
    print("="*60)
    for pid, r in reports.items():
        print(f"{pid}: Return={r['annualized_return']:.1%} | Sharpe={r['sharpe_ratio']:.2f} | MaxDD={r['max_drawdown']:.1%}")
    print("="*60)

    context["ti"].xcom_push(key="report_path",     value=report_path)
    context["ti"].xcom_push(key="portfolio_count", value=len(reports))


def export_csv(**context):
    import json
    import pandas as pd
    import os

    report_path    = context["ti"].xcom_pull(key="report_path",     task_ids="compute_risk_metrics")
    execution_date = context["ds"]

    with open(report_path) as f:
        reports = json.load(f)

    df = pd.DataFrame(list(reports.values()))
    csv_path = f"data/processed/analytics/master_summary_{execution_date}.csv"
    df.to_csv(csv_path, index=False)

    print(f"CSV exported → {csv_path}")
    print(df.to_string(index=False))

    context["ti"].xcom_push(key="csv_path", value=csv_path)


def send_summary(**context):
    portfolio_count = context["ti"].xcom_pull(key="portfolio_count", task_ids="compute_risk_metrics")
    execution_date  = context["ds"]

    print("="*60)
    print(f"DAILY PIPELINE COMPLETE")
    print(f"Date:       {execution_date}")
    print(f"Portfolios: {portfolio_count}")
    print(f"Status:     SUCCESS")
    print("="*60)


# ── DAG ───────────────────────────────────────────────────────────────────────

with DAG(
    dag_id="mini_aladdin_daily_risk_pipeline",
    default_args=DEFAULT_ARGS,
    description="Daily portfolio risk analytics pipeline",
    schedule_interval="30 6 * * 1-5",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["finance", "risk", "daily"],
) as dag:

    check_market = BranchPythonOperator(
        task_id="check_market_open",
        python_callable=check_market_open,
    )

    skip = EmptyOperator(task_id="skip_pipeline")

    ingest = PythonOperator(
        task_id="ingest_market_data",
        python_callable=ingest_market_data,
    )

    validate = PythonOperator(
        task_id="validate_data",
        python_callable=validate_data,
    )

    risk = PythonOperator(
        task_id="compute_risk_metrics",
        python_callable=compute_risk_metrics,
    )

    export = PythonOperator(
        task_id="export_csv",
        python_callable=export_csv,
    )

    summary = PythonOperator(
        task_id="send_summary",
        python_callable=send_summary,
        trigger_rule=TriggerRule.ALL_DONE,
    )

    check_market >> [ingest, skip]
    ingest >> validate >> risk >> export >> summary
    skip >> summary