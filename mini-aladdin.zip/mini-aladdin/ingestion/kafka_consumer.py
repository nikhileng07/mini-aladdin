"""
kafka_consumer.py
-----------------
Consumes financial events from Kafka topics with:
- Manual offset commits (at-least-once delivery)
- Parallel topic consumption
- Graceful shutdown handling
- Message validation via Pydantic
- Writes to DuckDB for downstream processing
"""

import json
import signal
import threading
from datetime import datetime, timezone
from typing import Callable
from loguru import logger
from confluent_kafka import Consumer, KafkaError, KafkaException
from tenacity import retry, stop_after_attempt, wait_exponential
import duckdb
from pydantic import BaseModel, ValidationError
from config.settings import settings


# ── Message Validators ────────────────────────────────────────────────────────

class StockTickEvent(BaseModel):
    event_id: str
    symbol: str
    price: float
    volume: int
    timestamp: str
    source: str


class TransactionEvent(BaseModel):
    event_id: str
    portfolio_id: str
    symbol: str
    action: str
    quantity: float
    price: float
    notional: float
    currency: str
    timestamp: str


# ── DuckDB Sink ───────────────────────────────────────────────────────────────

class DuckDBSink:
    """
    Lightweight local OLAP sink.
    In prod, swap this for S3 + Glue/Athena or Redshift.
    """

    def __init__(self, db_path: str = "data/processed/mini_aladdin.duckdb"):
        self.conn = duckdb.connect(db_path)
        self._init_tables()
        logger.info("DuckDB sink ready | path={}", db_path)

    def _init_tables(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS stock_ticks (
                event_id    VARCHAR PRIMARY KEY,
                symbol      VARCHAR NOT NULL,
                price       DOUBLE NOT NULL,
                volume      BIGINT,
                timestamp   TIMESTAMPTZ,
                source      VARCHAR,
                ingested_at TIMESTAMPTZ DEFAULT now()
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                event_id     VARCHAR PRIMARY KEY,
                portfolio_id VARCHAR NOT NULL,
                symbol       VARCHAR NOT NULL,
                action       VARCHAR NOT NULL,
                quantity     DOUBLE NOT NULL,
                price        DOUBLE NOT NULL,
                notional     DOUBLE NOT NULL,
                currency     VARCHAR DEFAULT 'USD',
                timestamp    TIMESTAMPTZ,
                ingested_at  TIMESTAMPTZ DEFAULT now()
            )
        """)
        # Index for fast portfolio lookups
        self.conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_txn_portfolio
            ON transactions(portfolio_id, timestamp)
        """)

    def insert_tick(self, event: StockTickEvent):
        self.conn.execute("""
            INSERT OR IGNORE INTO stock_ticks
            (event_id, symbol, price, volume, timestamp, source)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            event.event_id, event.symbol, event.price,
            event.volume, event.timestamp, event.source
        ])

    def insert_transaction(self, event: TransactionEvent):
        self.conn.execute("""
            INSERT OR IGNORE INTO transactions
            (event_id, portfolio_id, symbol, action, quantity, price, notional, currency, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            event.event_id, event.portfolio_id, event.symbol,
            event.action, event.quantity, event.price,
            event.notional, event.currency, event.timestamp
        ])

    def close(self):
        self.conn.close()


# ── Base Consumer ─────────────────────────────────────────────────────────────

class BaseKafkaConsumer:
    """
    Base consumer with:
    - Manual offset commits after successful processing
    - Graceful shutdown via SIGINT/SIGTERM
    - Exponential backoff on transient errors
    """

    def __init__(self, group_id: str, topics: list[str]):
        self.conf = {
            "bootstrap.servers": settings.KAFKA_BOOTSTRAP_SERVERS,
            "group.id": group_id,
            "client.id": f"mini-aladdin-{group_id}",
            "auto.offset.reset": "earliest",
            "enable.auto.commit": False,          # Manual commits only
            "max.poll.interval.ms": 300000,
            "session.timeout.ms": 30000,
            "heartbeat.interval.ms": 10000,
            "fetch.min.bytes": 1024,
            "fetch.max.wait.ms": 500,
        }
        self.consumer = Consumer(self.conf)
        self.topics = topics
        self._running = False
        self._lock = threading.Lock()

        # Graceful shutdown hooks
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    def _shutdown(self, signum, frame):
        logger.warning("Shutdown signal received — stopping consumer...")
        self._running = False

    def process_message(self, key: str, value: dict) -> bool:
        """Override in subclass. Return True on success, False to send to DLQ."""
        raise NotImplementedError

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        reraise=True
    )
    def _safe_process(self, key: str, value: dict) -> bool:
        return self.process_message(key, value)

    def run(self, poll_timeout: float = 1.0):
        self.consumer.subscribe(self.topics)
        self._running = True
        processed = 0
        errors = 0

        logger.info("Consumer started | topics={} | group={}", self.topics, self.conf["group.id"])

        try:
            while self._running:
                msg = self.consumer.poll(timeout=poll_timeout)

                if msg is None:
                    continue

                if msg.error():
                    if msg.error().code() == KafkaError._PARTITION_EOF:
                        logger.debug("End of partition reached")
                    else:
                        logger.error("Kafka error: {}", msg.error())
                        errors += 1
                    continue

                try:
                    key = msg.key().decode("utf-8") if msg.key() else ""
                    value = json.loads(msg.value().decode("utf-8"))

                    success = self._safe_process(key, value)

                    if success:
                        # Commit offset only after successful processing
                        self.consumer.commit(message=msg, asynchronous=False)
                        processed += 1
                    else:
                        errors += 1

                except json.JSONDecodeError as e:
                    logger.error("JSON decode error | offset={} | error={}", msg.offset(), e)
                    errors += 1
                except Exception as e:
                    logger.error("Unexpected error | offset={} | error={}", msg.offset(), e)
                    errors += 1

        finally:
            self.consumer.close()
            logger.info("Consumer stopped | processed={} | errors={}", processed, errors)


# ── Stock Tick Consumer ───────────────────────────────────────────────────────

class StockTickConsumer(BaseKafkaConsumer):

    def __init__(self, sink: DuckDBSink):
        super().__init__(
            group_id="mini-aladdin-tick-consumer",
            topics=["mini-aladdin.stock-ticks"]
        )
        self.sink = sink

    def process_message(self, key: str, value: dict) -> bool:
        try:
            event = StockTickEvent(**value)
            self.sink.insert_tick(event)
            logger.debug("Tick ingested | symbol={} | price={}", event.symbol, event.price)
            return True
        except ValidationError as e:
            logger.warning("Tick validation failed | key={} | errors={}", key, e.errors())
            return False


# ── Transaction Consumer ──────────────────────────────────────────────────────

class TransactionConsumer(BaseKafkaConsumer):

    def __init__(self, sink: DuckDBSink):
        super().__init__(
            group_id="mini-aladdin-txn-consumer",
            topics=["mini-aladdin.transactions"]
        )
        self.sink = sink

    def process_message(self, key: str, value: dict) -> bool:
        try:
            event = TransactionEvent(**value)
            self.sink.insert_transaction(event)
            logger.info(
                "Transaction ingested | portfolio={} | {} {} {} @ {}",
                event.portfolio_id, event.action, event.quantity, event.symbol, event.price
            )
            return True
        except ValidationError as e:
            logger.warning("Transaction validation failed | key={} | errors={}", key, e.errors())
            return False


# ── Parallel Consumer Runner ──────────────────────────────────────────────────

def run_consumers_parallel():
    """Run tick and transaction consumers in separate threads."""
    sink = DuckDBSink()

    tick_consumer = StockTickConsumer(sink)
    txn_consumer = TransactionConsumer(sink)

    tick_thread = threading.Thread(target=tick_consumer.run, name="tick-consumer", daemon=True)
    txn_thread = threading.Thread(target=txn_consumer.run, name="txn-consumer", daemon=True)

    tick_thread.start()
    txn_thread.start()

    logger.info("Both consumers running in parallel threads")

    tick_thread.join()
    txn_thread.join()

    sink.close()
    logger.info("All consumers shut down cleanly")


if __name__ == "__main__":
    run_consumers_parallel()