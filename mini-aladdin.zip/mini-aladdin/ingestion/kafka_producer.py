"""
kafka_producer.py
-----------------
Produces financial market data (stock prices, portfolio transactions)
to Kafka topics with Avro serialization, retry logic, and dead-letter queue.
"""

import json
import time
import random
from datetime import datetime, timezone
from typing import Any
from loguru import logger
from confluent_kafka import Producer, KafkaException
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import yfinance as yf
import pandas as pd
from pydantic import BaseModel, Field
from config.settings import settings


# ── Pydantic Models (Data Contracts) ────────────────────────────────────────

class StockTickEvent(BaseModel):
    event_id: str
    symbol: str
    price: float
    volume: int
    market_cap: float | None = None
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    source: str = "yfinance"


class TransactionEvent(BaseModel):
    event_id: str
    portfolio_id: str
    symbol: str
    action: str                  # BUY | SELL
    quantity: float
    price: float
    notional: float
    currency: str = "USD"
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ── Kafka Producer ───────────────────────────────────────────────────────────

class FinancialDataProducer:
    """
    Wraps confluent_kafka.Producer with:
    - Delivery confirmation callbacks
    - Dead-letter queue for failed messages
    - Retry logic via tenacity
    - Structured logging via loguru
    """

    TOPICS = {
        "stock_ticks": "mini-aladdin.stock-ticks",
        "transactions": "mini-aladdin.transactions",
        "dead_letter": "mini-aladdin.dead-letter",
    }

    def __init__(self):
        self.conf = {
            "bootstrap.servers": settings.KAFKA_BOOTSTRAP_SERVERS,
            "client.id": "mini-aladdin-producer",
            "acks": "all",                        # Wait for all replicas
            "retries": 5,
            "retry.backoff.ms": 500,
            "linger.ms": 10,                      # Batch messages for throughput
            "batch.size": 65536,                  # 64KB batch
            "compression.type": "lz4",            # Compress payloads
            "enable.idempotence": True,            # Exactly-once semantics
            "delivery.timeout.ms": 30000,
        }
        self.producer = Producer(self.conf)
        self._delivered = 0
        self._failed = 0
        logger.info("Kafka producer initialized | servers={}", settings.KAFKA_BOOTSTRAP_SERVERS)

    def _delivery_callback(self, err, msg):
        """Called once per message after broker acknowledgement."""
        if err:
            self._failed += 1
            logger.error(
                "Delivery FAILED | topic={} | key={} | error={}",
                msg.topic(), msg.key(), err
            )
            self._send_to_dlq(msg.value())
        else:
            self._delivered += 1
            logger.debug(
                "Delivered | topic={} | partition={} | offset={}",
                msg.topic(), msg.partition(), msg.offset()
            )

    def _send_to_dlq(self, value: bytes):
        """Push failed messages to dead-letter queue for inspection."""
        try:
            self.producer.produce(
                topic=self.TOPICS["dead_letter"],
                value=value,
                callback=None
            )
        except Exception as e:
            logger.critical("DLQ write failed: {}", e)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type(KafkaException),
        reraise=True
    )
    def publish(self, topic: str, key: str, payload: dict) -> None:
        """Serialize and publish a message to a Kafka topic."""
        try:
            self.producer.produce(
                topic=topic,
                key=key.encode("utf-8"),
                value=json.dumps(payload).encode("utf-8"),
                callback=self._delivery_callback,
            )
            self.producer.poll(0)   # Trigger callbacks without blocking
        except BufferError:
            logger.warning("Producer buffer full — flushing...")
            self.producer.flush(timeout=10)
            raise KafkaException("Buffer full, retrying")

    def flush(self, timeout: int = 30):
        remaining = self.producer.flush(timeout=timeout)
        logger.info(
            "Flush complete | delivered={} | failed={} | remaining={}",
            self._delivered, self._failed, remaining
        )

    def stats(self) -> dict:
        return {"delivered": self._delivered, "failed": self._failed}


# ── Data Fetcher ─────────────────────────────────────────────────────────────

class MarketDataFetcher:
    """Pulls live + historical data from yfinance and emits to Kafka."""

    def __init__(self, producer: FinancialDataProducer):
        self.producer = producer

    def fetch_and_publish_ticks(self, symbols: list[str], interval: str = "1m"):
        """
        Fetch 1-minute tick data for a list of symbols and publish to Kafka.
        In prod this would be replaced with a real market data feed (Bloomberg, Refinitiv).
        """
        logger.info("Fetching ticks | symbols={} | interval={}", symbols, interval)
        data = yf.download(
            tickers=symbols,
            period="1d",
            interval=interval,
            group_by="ticker",
            threads=True,
            progress=False,
        )

        for symbol in symbols:
            try:
                df = data[symbol] if len(symbols) > 1 else data
                df = df.dropna()
                for ts, row in df.iterrows():
                    event = StockTickEvent(
                        event_id=f"{symbol}-{ts.isoformat()}",
                        symbol=symbol,
                        price=round(float(row["Close"]), 4),
                        volume=int(row["Volume"]),
                    )
                    self.producer.publish(
                        topic=FinancialDataProducer.TOPICS["stock_ticks"],
                        key=symbol,
                        payload=event.model_dump(),
                    )
            except Exception as e:
                logger.error("Failed to publish ticks for {} | error={}", symbol, e)

        self.producer.flush()
        logger.info("Tick publish complete")

    def simulate_transactions(self, portfolio_id: str, symbols: list[str], n: int = 100):
        """
        Simulate portfolio transactions and publish to Kafka.
        Replace with real OMS feed in production.
        """
        logger.info("Simulating {} transactions for portfolio={}", n, portfolio_id)
        for i in range(n):
            symbol = random.choice(symbols)
            action = random.choice(["BUY", "SELL"])
            quantity = round(random.uniform(10, 500), 2)
            price = round(random.uniform(50, 3000), 2)

            event = TransactionEvent(
                event_id=f"txn-{portfolio_id}-{i}-{int(time.time())}",
                portfolio_id=portfolio_id,
                symbol=symbol,
                action=action,
                quantity=quantity,
                price=price,
                notional=round(quantity * price, 2),
            )
            self.producer.publish(
                topic=FinancialDataProducer.TOPICS["transactions"],
                key=portfolio_id,
                payload=event.model_dump(),
            )
            time.sleep(0.01)   # Throttle to avoid hammering broker

        self.producer.flush()
        logger.info("Transaction simulation complete")


# ── Entrypoint ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    SYMBOLS = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "JPM", "GS", "BAC"]

    producer = FinancialDataProducer()
    fetcher = MarketDataFetcher(producer)

    fetcher.fetch_and_publish_ticks(symbols=SYMBOLS, interval="1m")
    fetcher.simulate_transactions(portfolio_id="PORT-001", symbols=SYMBOLS, n=500)

    logger.info("Producer stats: {}", producer.stats())