"""
spark_processor.py
------------------
PySpark jobs for processing raw financial data:
- Reads from DuckDB / Parquet on S3
- Computes rolling returns, VWAP, portfolio weights
- Writes processed data back to S3 (MinIO) as Parquet
"""

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import (
    StructType, StructField, StringType,
    DoubleType, LongType, TimestampType
)
from loguru import logger
from config.settings import settings


# ── Spark Session Factory ─────────────────────────────────────────────────────

def create_spark_session(app_name: str = "MiniAladdin") -> SparkSession:
    """
    Build a SparkSession configured for:
    - S3/MinIO access via Hadoop AWS
    - Delta Lake support
    - Optimized shuffle partitions
    """
    spark = (
        SparkSession.builder
        .appName(app_name)
        .master(settings.SPARK_MASTER_URL)
        .config("spark.sql.shuffle.partitions", "8")         # Tune for local dev
        .config("spark.sql.adaptive.enabled", "true")         # AQE for auto-optimization
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.hadoop.fs.s3a.endpoint", settings.MINIO_ENDPOINT)
        .config("spark.hadoop.fs.s3a.access.key", settings.MINIO_ACCESS_KEY)
        .config("spark.hadoop.fs.s3a.secret.key", settings.MINIO_SECRET_KEY)
        .config("spark.hadoop.fs.s3a.path.style.access", "true")
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        .config("spark.jars.packages",
                "org.apache.hadoop:hadoop-aws:3.3.4,"
                "com.amazonaws:aws-java-sdk-bundle:1.12.262")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    logger.info("SparkSession created | master={}", settings.SPARK_MASTER_URL)
    return spark


# ── Schema Definitions ────────────────────────────────────────────────────────

TICK_SCHEMA = StructType([
    StructField("event_id",    StringType(),    False),
    StructField("symbol",      StringType(),    False),
    StructField("price",       DoubleType(),    False),
    StructField("volume",      LongType(),      True),
    StructField("timestamp",   TimestampType(), False),
    StructField("source",      StringType(),    True),
])

TXN_SCHEMA = StructType([
    StructField("event_id",     StringType(),    False),
    StructField("portfolio_id", StringType(),    False),
    StructField("symbol",       StringType(),    False),
    StructField("action",       StringType(),    False),
    StructField("quantity",     DoubleType(),    False),
    StructField("price",        DoubleType(),    False),
    StructField("notional",     DoubleType(),    False),
    StructField("currency",     StringType(),    True),
    StructField("timestamp",    TimestampType(), False),
])


# ── Processor Class ───────────────────────────────────────────────────────────

class FinancialDataProcessor:

    def __init__(self, spark: SparkSession):
        self.spark = spark
        self.s3_base = f"s3a://{settings.MINIO_BUCKET}"

    # ── Readers ──────────────────────────────────────────────────────────────

    def read_ticks(self, path: str = None) -> DataFrame:
        path = path or f"{self.s3_base}/raw/stock_ticks/"
        logger.info("Reading ticks from {}", path)
        return (
            self.spark.read
            .schema(TICK_SCHEMA)
            .parquet(path)
        )

    def read_transactions(self, path: str = None) -> DataFrame:
        path = path or f"{self.s3_base}/raw/transactions/"
        logger.info("Reading transactions from {}", path)
        return (
            self.spark.read
            .schema(TXN_SCHEMA)
            .parquet(path)
        )

    # ── Tick Processing ───────────────────────────────────────────────────────

    def compute_vwap(self, ticks: DataFrame) -> DataFrame:
        """
        Volume-Weighted Average Price per symbol per day.
        VWAP = sum(price * volume) / sum(volume)
        """
        return (
            ticks
            .withColumn("date", F.to_date("timestamp"))
            .withColumn("pv", F.col("price") * F.col("volume"))
            .groupBy("symbol", "date")
            .agg(
                F.sum("pv").alias("sum_pv"),
                F.sum("volume").alias("sum_vol"),
                F.count("*").alias("tick_count"),
                F.first("price").alias("open"),
                F.last("price").alias("close"),
                F.max("price").alias("high"),
                F.min("price").alias("low"),
            )
            .withColumn("vwap", F.round(F.col("sum_pv") / F.col("sum_vol"), 4))
            .drop("sum_pv")
        )

    def compute_rolling_returns(self, ticks: DataFrame, windows: list[int] = [1, 5, 20]) -> DataFrame:
        """
        Compute log returns over N-day rolling windows per symbol.
        Log return = ln(P_t / P_{t-n})
        """
        daily = self.compute_vwap(ticks)
        w = Window.partitionBy("symbol").orderBy("date")

        df = daily.withColumn("prev_close_1d", F.lag("close", 1).over(w))

        for n in windows:
            df = (
                df
                .withColumn(f"prev_close_{n}d", F.lag("close", n).over(w))
                .withColumn(
                    f"log_return_{n}d",
                    F.round(F.log(F.col("close") / F.col(f"prev_close_{n}d")), 6)
                )
                .drop(f"prev_close_{n}d")
            )

        return df.drop("prev_close_1d")

    # ── Transaction Processing ────────────────────────────────────────────────

    def compute_portfolio_weights(self, transactions: DataFrame) -> DataFrame:
        """
        Compute current portfolio weights from transaction history.
        Net position per symbol = sum(BUY notional) - sum(SELL notional)
        Weight = position / total_portfolio_value
        """
        net_positions = (
            transactions
            .withColumn(
                "signed_notional",
                F.when(F.col("action") == "BUY", F.col("notional"))
                 .otherwise(-F.col("notional"))
            )
            .groupBy("portfolio_id", "symbol")
            .agg(
                F.sum("signed_notional").alias("net_notional"),
                F.sum(
                    F.when(F.col("action") == "BUY", F.col("quantity"))
                     .otherwise(-F.col("quantity"))
                ).alias("net_quantity")
            )
            .filter(F.col("net_notional") > 0)   # Long positions only
        )

        total_value = (
            net_positions
            .groupBy("portfolio_id")
            .agg(F.sum("net_notional").alias("total_value"))
        )

        return (
            net_positions
            .join(total_value, on="portfolio_id", how="left")
            .withColumn("weight", F.round(F.col("net_notional") / F.col("total_value"), 6))
            .orderBy("portfolio_id", F.col("weight").desc())
        )

    def compute_turnover(self, transactions: DataFrame) -> DataFrame:
        """
        Monthly portfolio turnover = total traded / avg portfolio value.
        High turnover = high transaction costs in real life.
        """
        return (
            transactions
            .withColumn("month", F.date_trunc("month", F.col("timestamp")))
            .groupBy("portfolio_id", "month")
            .agg(
                F.sum("notional").alias("total_traded"),
                F.countDistinct("symbol").alias("unique_symbols"),
                F.count("*").alias("trade_count"),
            )
            .orderBy("portfolio_id", "month")
        )

    # ── Writers ───────────────────────────────────────────────────────────────

    def write_parquet(self, df: DataFrame, path: str, partition_by: list[str] = None):
        """Write DataFrame to S3/MinIO as Parquet with optional partitioning."""
        writer = df.write.mode("overwrite").format("parquet")
        if partition_by:
            writer = writer.partitionBy(*partition_by)
        writer.save(path)
        logger.info("Written to {} | rows={}", path, df.count())

    # ── Full Pipeline ─────────────────────────────────────────────────────────

    def run(self):
        logger.info("Starting Spark processing pipeline")

        ticks = self.read_ticks()
        transactions = self.read_transactions()

        # VWAP + returns
        returns_df = self.compute_rolling_returns(ticks, windows=[1, 5, 20])
        self.write_parquet(
            returns_df,
            f"{self.s3_base}/processed/returns/",
            partition_by=["symbol"]
        )

        # Portfolio weights
        weights_df = self.compute_portfolio_weights(transactions)
        self.write_parquet(
            weights_df,
            f"{self.s3_base}/processed/portfolio_weights/"
        )

        # Turnover
        turnover_df = self.compute_turnover(transactions)
        self.write_parquet(
            turnover_df,
            f"{self.s3_base}/processed/turnover/"
        )

        logger.info("Spark pipeline complete")


if __name__ == "__main__":
    spark = create_spark_session()
    processor = FinancialDataProcessor(spark)
    processor.run()
    spark.stop()