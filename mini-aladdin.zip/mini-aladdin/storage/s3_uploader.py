"""
s3_uploader.py
--------------
High-level S3/MinIO storage layer:
- Upload/download files and DataFrames
- Parquet read/write with partition pruning
- Bucket lifecycle management
- Presigned URLs for dashboard access
"""

import io
import os
import json
from pathlib import Path
from typing import Optional
import boto3
import awswrangler as wr
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from botocore.exceptions import ClientError
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential
from config.settings import settings


class S3StorageManager:
    """
    Wraps boto3 + awswrangler for clean S3/MinIO interactions.
    Automatically creates buckets if missing.
    """

    BUCKET = settings.MINIO_BUCKET

    def __init__(self):
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.MINIO_ENDPOINT,
            aws_access_key_id=settings.MINIO_ACCESS_KEY,
            aws_secret_access_key=settings.MINIO_SECRET_KEY,
            region_name="us-east-1",
        )
        self.resource = boto3.resource(
            "s3",
            endpoint_url=settings.MINIO_ENDPOINT,
            aws_access_key_id=settings.MINIO_ACCESS_KEY,
            aws_secret_access_key=settings.MINIO_SECRET_KEY,
        )

        # Configure awswrangler to use MinIO
        wr.config.s3_endpoint_url = settings.MINIO_ENDPOINT

        self._ensure_bucket()
        logger.info("S3StorageManager ready | bucket={} | endpoint={}", self.BUCKET, settings.MINIO_ENDPOINT)

    def _ensure_bucket(self):
        """Create bucket if it doesn't exist."""
        try:
            self.client.head_bucket(Bucket=self.BUCKET)
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                self.client.create_bucket(Bucket=self.BUCKET)
                logger.info("Created bucket: {}", self.BUCKET)
                self._set_bucket_lifecycle()
            else:
                raise

    def _set_bucket_lifecycle(self):
        """Auto-delete raw data after 30 days, keep processed forever."""
        lifecycle = {
            "Rules": [
                {
                    "ID": "expire-raw-data",
                    "Status": "Enabled",
                    "Filter": {"Prefix": "raw/"},
                    "Expiration": {"Days": 30},
                },
                {
                    "ID": "transition-processed-to-glacier",
                    "Status": "Enabled",
                    "Filter": {"Prefix": "processed/"},
                    "Transitions": [
                        {"Days": 90, "StorageClass": "GLACIER"}
                    ],
                },
            ]
        }
        try:
            self.client.put_bucket_lifecycle_configuration(
                Bucket=self.BUCKET,
                LifecycleConfiguration=lifecycle
            )
        except Exception:
            pass   # MinIO may not support all lifecycle rules

    # ── Upload ────────────────────────────────────────────────────────────────

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def upload_file(self, local_path: str, s3_key: str) -> str:
        """Upload a local file to S3. Returns s3:// URI."""
        self.client.upload_file(local_path, self.BUCKET, s3_key)
        uri = f"s3://{self.BUCKET}/{s3_key}"
        logger.info("Uploaded {} → {}", local_path, uri)
        return uri

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def upload_json(self, data: dict, s3_key: str) -> str:
        """Serialize dict to JSON and upload."""
        body = json.dumps(data, default=str, indent=2).encode("utf-8")
        self.client.put_object(Body=body, Bucket=self.BUCKET, Key=s3_key, ContentType="application/json")
        uri = f"s3://{self.BUCKET}/{s3_key}"
        logger.info("Uploaded JSON → {}", uri)
        return uri

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def upload_dataframe(
        self,
        df: pd.DataFrame,
        s3_key: str,
        format: str = "parquet",
        partition_cols: list[str] = None,
    ) -> str:
        """
        Upload pandas DataFrame to S3 as Parquet or CSV.
        Parquet is strongly preferred — 10x smaller, typed, splittable.
        """
        s3_path = f"s3://{self.BUCKET}/{s3_key}"

        if format == "parquet":
            wr.s3.to_parquet(
                df=df,
                path=s3_path,
                dataset=partition_cols is not None,
                partition_cols=partition_cols,
                compression="snappy",
                mode="overwrite",
            )
        elif format == "csv":
            buffer = io.StringIO()
            df.to_csv(buffer, index=False)
            self.client.put_object(
                Body=buffer.getvalue().encode("utf-8"),
                Bucket=self.BUCKET,
                Key=s3_key,
                ContentType="text/csv",
            )

        logger.info("Uploaded DataFrame → {} | rows={} | format={}", s3_path, len(df), format)
        return s3_path

    # ── Download ──────────────────────────────────────────────────────────────

    def download_dataframe(
        self,
        s3_path: str,
        filters: list = None,
        columns: list[str] = None,
    ) -> pd.DataFrame:
        """
        Read Parquet from S3 with optional partition pruning.
        filters: e.g. [("symbol", "=", "AAPL"), ("date", ">=", "2024-01-01")]
        """
        df = wr.s3.read_parquet(
            path=s3_path,
            filters=filters,
            columns=columns,
            dataset=True,
        )
        logger.info("Downloaded {} | rows={}", s3_path, len(df))
        return df

    def download_json(self, s3_key: str) -> dict:
        obj = self.client.get_object(Bucket=self.BUCKET, Key=s3_key)
        return json.loads(obj["Body"].read().decode("utf-8"))

    def download_file(self, s3_key: str, local_path: str):
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        self.client.download_file(self.BUCKET, s3_key, local_path)
        logger.info("Downloaded s3://{}/{} → {}", self.BUCKET, s3_key, local_path)

    # ── List & Check ──────────────────────────────────────────────────────────

    def list_keys(self, prefix: str = "") -> list[str]:
        paginator = self.client.get_paginator("list_objects_v2")
        keys = []
        for page in paginator.paginate(Bucket=self.BUCKET, Prefix=prefix):
            for obj in page.get("Contents", []):
                keys.append(obj["Key"])
        return keys

    def exists(self, s3_key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.BUCKET, Key=s3_key)
            return True
        except ClientError:
            return False

    def get_size(self, s3_key: str) -> int:
        """Return object size in bytes."""
        try:
            response = self.client.head_object(Bucket=self.BUCKET, Key=s3_key)
            return response["ContentLength"]
        except ClientError:
            return 0

    # ── Presigned URLs ────────────────────────────────────────────────────────

    def presigned_url(self, s3_key: str, expiry_seconds: int = 3600) -> str:
        """Generate a temporary public URL for dashboard data access."""
        url = self.client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.BUCKET, "Key": s3_key},
            ExpiresIn=expiry_seconds,
        )
        logger.debug("Generated presigned URL for {} (expires {}s)", s3_key, expiry_seconds)
        return url

    # ── Convenience: Risk Report Paths ────────────────────────────────────────

    def risk_report_key(self, date: str) -> str:
        return f"reports/risk/{date}/risk_report.json"

    def returns_path(self, symbol: str = None) -> str:
        base = f"s3://{self.BUCKET}/processed/returns/"
        return f"{base}symbol={symbol}/" if symbol else base

    def weights_path(self) -> str:
        return f"s3://{self.BUCKET}/processed/portfolio_weights/"


if __name__ == "__main__":
    manager = S3StorageManager()

    # Test upload
    test_df = pd.DataFrame({
        "symbol": ["AAPL", "MSFT", "GOOGL"],
        "price": [180.0, 420.0, 170.0],
        "date": ["2024-01-01"] * 3
    })
    manager.upload_dataframe(test_df, "test/sample_prices.parquet")

    # Test list
    keys = manager.list_keys("test/")
    logger.info("Keys in test/: {}", keys)